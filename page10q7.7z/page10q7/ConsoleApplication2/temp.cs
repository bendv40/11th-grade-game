﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class temp
    {
        private int counter=0;
        private char ch;
        
        public temp(int counter, char ch)
        {
            this.counter = counter;
            this.ch = ch;
        }
        public int Counter
        {
            get
            {
                return counter;
            }

        }

        public char Ch
        {
            get
            {
                return ch;
            }

        }
        public override string ToString()
        {
            return "ch=   "+ch+ " "+counter+" times";
        }

    }
}
