﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static int amount(Stack<char> s, char ch)
        {
            int counter =0;
            Stack<char> temp = new Stack<char>();
            while(!s.IsEmpty())
            {
                if (s.top() == ch)
                {
                    s.Pop();
                    counter++;
                }
                else
                {
                    temp.Push(s.Pop());
                }
            }
            while (!temp.IsEmpty())
            { 
                s.Push(temp.Pop());
            }
            return counter;


        }
        static Stack<temp> q7(Stack<char> s)
        {
            Stack<temp> s1 = new Stack<temp>();
            char x;
            int amounta =0;
            while (!s.IsEmpty())
            {
                x = s.top();
                amounta = amount(s, x);
                temp t = new temp(amounta, x);
                s1.Push(t);
            }
            return s1;
        }
        public static void print(Stack<temp> st)
        {
            while (!st.IsEmpty())
            {
                temp t = st.Pop();
                Console.WriteLine(t.Ch);
                Console.WriteLine(t.Counter);
                Console.WriteLine("====");
            }
        }
        static void Main(string[] args)
        {
            Stack<char> s = new Stack<char>();
            s.Push('r');
            s.Push('p');
            s.Push('l');
            s.Push('g');
            s.Push('p');
            s.Push('l');
            s.Push('r');
            Stack<temp> st = q7(s);
            print(st);
        }
    }
}
